// See https://github.com/dialogflow/dialogflow-fulfillment-nodejs
// for Dialogflow fulfillment library docs, samples, and to report issues
'use strict';

const Connection = require("salesforce-connector");
const conn = new Connection({ logLevel: "INFO" });
const functions = require('firebase-functions');
const { WebhookClient } = require('dialogflow-fulfillment');
const { Card, Suggestion } = require('dialogflow-fulfillment');

process.env.DEBUG = 'dialogflow:debug'; // enables lib debugging statements

exports.dialogflowFirebaseFulfillment = functions.https.onRequest((request, response) => {
	const agent = new WebhookClient({ request, response });
  
    function login() {
        return conn.login({
        username: "john@demo.com",
        password: "*******",
        security_token: "G6oNrdsw***********"
        });
    }

    function nameVerification(agent) {
        return new Promise((resolve, reject) => {
            conn.collection("Contact").select("Id, Name").where({
                Name: {
                    $like: agent.parameters.customerName + "%"
                }
            }).limit(5).run().then((resp) => {
                if (resp.records.length == 1) {
                    agent.add(request.body.queryResult.fulfillmentText);
                    agent.setContext({
                        'name': 'customerdata',
                        'lifespan': 5,
                        'parameters': { 'customerName': resp.records[0].Name }
                    });
                } else if (resp.records.length == 0) {
                    agent.setContext({ "name": "verify-name-followup", "lifespan": -1 });
                    if (!agent.getContext("support-followup").parameters.count) {
                        agent.setContext({
                            "name": "support-followup", "lifespan": 1, "parameters": {
                                count: 1
                            }
                        });
                        agent.add("No Customer available of such name. Please try again");
                    } else if (agent.getContext("support-followup").parameters.count < 2) {
                        agent.setContext({
                            "name": "support-followup", "lifespan": 1, "parameters": {
                                count: 2
                            }
                        });
                        agent.add("No Customer available of such name. Please try again");
                    } else {
                        agent.setContext({ "name": "support-followup", "lifespan": -1 });
                        agent.add("No Customer available of such name. Your session has been expired. Do you any other query?");
                    }
                } else if (resp.records.length > 1) {
                    agent.add("Please Choose among the following Names");
                }
                resp.records.forEach(record => {
                    agent.add(new Suggestion(record.Name));
                });
                return resolve();
            }).catch(err => {
              	agent.add("Oops.Something went wrong while fetching names.");
                return reject(err);
            });
        });
    }

    function verifyName(agent) {
        return new Promise((resolve, reject) => {
            conn.collection("Contact").select(["Id", "Name", "AccountId"]).joinTable([{ table: "Opportunity", fields: ["Id", "Name", "CloseDate"], condition: "WHERE Opportunity.IsClosed = false ORDER BY Opportunity.CloseDate DESC" }]).populateChild("Account").where({
                Name: (agent.getContext('customerdata') !== null) ? (agent.getContext('customerdata').parameters.customerName) : (agent.parameters.customerName)
            }).run().then(resp => {
                if (resp.records.length > 0) {
                    agent.setContext({
                        'name': 'customerdata',
                        'lifespan': 5,
                        'parameters': {
                            'customerName': resp.records[0].Name,
                            'customerId': resp.records[0].Id,
                            'Account': resp.records[0].Account.Name,
                            'AccountId': resp.records[0].AccountId
                        }
                    });
                    if (resp.records[0].Opportunities !== null) {
                        agent.add("Please choose any of the following Opportunity or enter case subject name.");
                        resp.records[0].Opportunities.records.forEach(record => {
                            agent.add(new Suggestion(record.Name + " | " + record.CloseDate));
                        });
                    } else {
                        agent.add("You don't have opportunities listed with your Account. Please enter the subject name to create case.");
                    }
                } else {
                    agent.add("No Customer available of such name. Please try again.");
                    agent.setContext({ "name": "verify-name-yes-followup", "lifespan": -1 });
                    agent.setContext({ "name": "verify-name-custom-followup", "lifespan": -1 });
                }
                return resolve();
            }).catch(err => {
              agent.add("Oops.Something went wrong while Name verification.");
                return reject();
            });
        });
    }

    function supportSuggestions(agent) {
        let customerDetails = agent.getContext('customerdata').parameters;
        customerDetails.opportunity = agent.parameters.opportunity.split("|")[0].trim();
        populateCustomerDetailsContext(agent, customerDetails);
        agent.add(request.body.queryResult.fulfillmentText);
        agent.add(new Suggestion("Competitive Support"));
        agent.add(new Suggestion("Pricing Support"));
        agent.add(new Suggestion("Legal Support"));
        agent.add(new Suggestion("Solution Engineering Support"));
    }

    function addSupport(agent) {
        let customerDetails = agent.getContext('customerdata').parameters;
        customerDetails['support-type'] = agent.parameters['support-type'];
        populateCustomerDetailsContext(agent, customerDetails);
        agent.add(request.body.queryResult.fulfillmentText);
        agent.add(new Suggestion("Yes"));
        agent.add(new Suggestion("No"));
    }

    function addNotes(agent) {
        let customerDetails = agent.getContext('customerdata').parameters;
        customerDetails.notes = agent.parameters.notes || "";
        populateCustomerDetailsContext(agent, customerDetails);
        agent.add(request.body.queryResult.fulfillmentText);
        agent.add(`Contact Name : ${customerDetails.customerName}`);
        agent.add(`Account Name : ${customerDetails.Account}`);
        agent.add(`Opportunity Name : ${customerDetails.opportunity}`);
        agent.add(`Support Type : ${customerDetails["support-type"]}`);
        agent.add(`Notes : ${customerDetails.notes}`);
        agent.add(new Suggestion("Yes"));
        agent.add(new Suggestion("No"));
    }

    function restartConversation(agent) {
        agent.setContext({ "name": "customerdata", "lifespan": -1 });
        agent.add("Okay. Do you have any other query?");
    }

    function createCase(agent) {
        let customerDetails = agent.getContext('customerdata').parameters;
        agent.setContext({ "name": "customerdata", "lifespan": -1 });
        let caseBody = {
            ContactId: customerDetails.customerId,
            AccountId: customerDetails.AccountId,
            Type: customerDetails['support-type'],
            Status: 'Open',
            Reason: customerDetails.notes,
            Origin: 'Chat',
            Subject: customerDetails.opportunity,
            Priority: 'High'
        };
        return new Promise((resolve, reject) => {
            conn.collection('Case').create(caseBody).then((resp) => {
                agent.setContext({ "name": "customerdata", "lifespan": -1 });
                agent.add(request.body.queryResult.fulfillmentText);
                return resolve();
            }).catch(err => {
              	agent.add("Oops.Something went wrong while creating case.");
                return reject(err);
            });
        });
    }

    function fallBackSupport(agent) {
        if (!agent.getContext("deal_support_type-followup").parameters.count) {
            agent.setContext({
                "name": "deal_support_type-followup", "lifespan": 1, "parameters": {
                    count: 1
                }
            });
            agent.add(request.body.queryResult.fulfillmentText);
            agent.add(new Suggestion("Competitive Support"));
            agent.add(new Suggestion("Pricing Support"));
            agent.add(new Suggestion("Legal Support"));
            agent.add(new Suggestion("Solution Engineering Support"));
        } else if (agent.getContext("deal_support_type-followup").parameters.count < 2) {
            agent.setContext({
                "name": "deal_support_type-followup", "lifespan": 1, "parameters": {
                    count: 2
                }
            });
            agent.add(request.body.queryResult.fulfillmentText);
            agent.add(new Suggestion("Competitive Support"));
            agent.add(new Suggestion("Pricing Support"));
            agent.add(new Suggestion("Legal Support"));
            agent.add(new Suggestion("Solution Engineering Support"));
        } else {
            agent.setContext({ "name": "deal_support_type-followup", "lifespan": -1 });
          	agent.setContext({ "name": "customerdata", "lifespan": -1 });
            agent.add("Your Session has expired. Do you have any query?");
        }
    }
  
  	function defaultFallBack(agent) {
    	agent.setContext({ "name": "customerdata", "lifespan": -1 });
      	agent.add(request.body.queryResult.fulfillmentText);
    }

    function populateCustomerDetailsContext(agent, contextData) {
        agent.setContext({ "name": "customerdata", "lifespan": -1 });
        agent.setContext({
            'name': 'customerdata',
            'lifespan': 5,
            'parameters': contextData
        });
    }


    login().then((userInfo) => {
        let intentMap = new Map();
        intentMap.set('verify-name', nameVerification);
        intentMap.set('verify-name - yes', verifyName);
        intentMap.set('verify-name - custom', verifyName);
        intentMap.set('open-opportunity', supportSuggestions);
        intentMap.set('verify-name - custom - custom', supportSuggestions);
        intentMap.set('deal_support_type', addSupport);
        intentMap.set('notes_new', addNotes);
        intentMap.set('deal_support_type - no', addNotes);
        intentMap.set('notes_new - yes', createCase);
        intentMap.set('deal_support_type - no - yes', createCase);
        intentMap.set('notes_new - no', restartConversation);
        intentMap.set('deal_support_type - no - no', restartConversation);
        intentMap.set('deal_support_type - fallback', fallBackSupport);
      	intentMap.set('Default Fallback Intent', defaultFallBack);
        agent.handleRequest(intentMap);
    }).catch(err => {
      	agent.add("Something went wrong while fetching data");
        response.status(500).json(err);
    });
});
