// See https://github.com/dialogflow/dialogflow-fulfillment-nodejs
// for Dialogflow fulfillment library docs, samples, and to report issues
"use strict";

const functions = require("firebase-functions");
const Connection = require("salesforce-connector");
const conn = new Connection({ logLevel: "INFO" });
const { WebhookClient } = require("dialogflow-fulfillment");
const { Suggestion } = require("dialogflow-fulfillment");

process.env.DEBUG = "dialogflow:debug"; // enables lib debugging statements

let numberOfTries = 3;
let accountNameTries = 1;

exports.dialogflowFirebaseFulfillment = functions.https.onRequest((req, res) => {
    const agent = new WebhookClient({ request: req, response: res });
    let intentMap = new Map();
    function login(){
        return conn.login({
        username: "john@demo.com",
        password: "*******",
        security_token: "G6oNrdsw***********"
        });
    }

    function welcome(agent) {
        agent.add("Welcome to my agent!");
    }

    function fallback(agent) {
        agent.add("I didn't understand");
        agent.add("I'm sorry, can you try again?");
    }

    function formatPhoneNumber(phoneNumberString) {
        let cleaned = ("" + phoneNumberString).replace(/\D/g, "");
        let match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
        if (match) {
            return "(" + match[1] + ")" + match[2] + "-" + match[3];
        }
        return null;
    }
	
  	/***
    	phone-number intent handler
    	@params Agent {WebhookClient}    	
    **/
    function phoneNumber(agent){
        console.log(agent.originalRequest.source, "%%%%%");
        return new Promise((resolve, reject) => {
        // get user input
            let phoneNumber = formatPhoneNumber(agent.parameters["phone-number"]);
            console.log(phoneNumber);

            if (phoneNumber != null) {
                // search for Account with Phone Number
                conn.collection("Account").select("Id,Name,pin_number__c").where({
                    "Phone": phoneNumber
                }).limit(5).run().then(response => {
                    console.log("Salesforce Response", response.records, response.records.length);
                    console.log("CHECK CONDITION", response.records.length > 0);
                    numberOfTries = 3;
                  	// send response
                    if (response.records.length > 0){
                        switch (agent.originalRequest.source){
                            case "GOOGLE_TELEPHONY":

                            	let text = "<speak>Please choose the account";
                            	response.records.forEach((record, idx) => {
                                	text += ` <break time="1s"/> ${idx + 1} ${record.Name}`;
                              });
                            text += "</speak>";
                            console.log("text", text);
                                res.json({ 
                                          "fulfillmentMessages":[{
                                          "platform": "TELEPHONY",
                                          "telephonySynthesizeSpeech": {
                                              "ssml": text
                                          }}],
                                    "outputContexts": [
                                        {
                                            "name": `projects/qai-salesforce-ext/agent/sessions/${req.responseId}/contexts/phone_number_context`,
                                            "lifespanCount": 2,
                                            "parameters": {
                                                "phone_number": phoneNumber
                                            }
                                        }
                                    ]
                                });
                                break;
                            default:
                                agent.setContext({
                                    "name": "phone_number_context",
                                    "lifespan": 2,
                                    "parameters": { "phone_number": phoneNumber, "phone_number_options": response.records } });
                                agent.add("Please choose the account");

                                response.records.forEach(record => {
                                    agent.add(new Suggestion(record.Name));
                                });
                        }

                        return resolve();
                    } else {
                        switch (agent.originalRequest.source){
                        case "GOOGLE_TELEPHONY":
                            res.json({'fulfillmentText': "No account found for the phone number",
                                 "outputContexts": [
                                     {
                                            "name": `projects/qai-salesforce-ext/agent/sessions/${req.responseId}/contexts/phone-number-followup`,
                                            "lifespanCount": -1
                                        },
                                    {
                                            "name": `projects/qai-salesforce-ext/agent/sessions/${req.responseId}/contexts/appointment-followup`,
                                            "lifespanCount": 5
                                        } 
                                 ]
                                });
                            break;
                        default:
                            agent.add("No account found for the phone number");
                            agent.setContext({ "name": "phone-number-followup", "lifespan": -1 });
                            agent.setContext({"name": "appointment-followup"});
                    }
                        return resolve();
                    }
                }).catch(err => {
                    console.error(err);
                    switch (agent.originalRequest.source){
                        case "GOOGLE_TELEPHONY":
                            res.json({'fulfillmentText': "Something went wrong while fetching data"});
                            break;
                        default:
                            agent.add("Something went wrong while fetching data");
                    }
                    return reject();
                });
            } else {
                agent.add("Please enter a valid phone number");
              	agent.setContext({"name": "appointment-followup", "lifespan": 1});
                agent.setContext({ "name": "phone-number-followup", "lifespan": -1 });
                return resolve();
            }
        });
    }
	
  	/***
    	choose-account intent handler
    	@params Agent {WebhookClient}    	
    **/
    function chooseAccount(agent){
        console.log("CHOOSEN ACCOUNT", agent.parameters['account-name']);
        let phone_number = agent.getContext("phone_number_context").parameters.phone_number || null;
        let phone_number_options = agent.getContext("phone_number_context").parameters.phone_number_options || null;
		return new Promise((resolve, reject)=> {
        	conn.collection("Account").select("Id, Name").where({
                "Phone": phone_number,
                "Name": agent.parameters['account-name']
            }).run().then(resp => {
                console.log(resp,'&&&&&');
                switch (agent.originalRequest.source){
                    case "GOOGLE_TELEPHONY":
                        if(resp.records.length > 0){
                            res.json({ "fulfillmentText": 'Please enter your PIN',
                              "outputContexts": [
                                  {
                                      "name": `projects/qai-salesforce-ext/agent/sessions/${req.responseId}/contexts/account_name_context`,
                                      "lifespanCount": 1,
                                      "parameters": {
                                          "account_name": agent.parameters['account-name']
                                      }
                                  }
                              ]
                          });
                        }else{
                            res.json({ "fulfillmentText": 'Sorry!! I think I misheard you.I could not find any account. Please renter your phone number',"outputContexts":[
                                {
                                    "name": `projects/qai-salesforce-ext/agent/sessions/${req.responseId}/contexts/appointment-followup`,
                                    "lifespanCount": 1,
                                }
                            ]});
                   
                        }
                        break;
                    default:
                        if(resp.records.length > 0){
                            agent.add('Please enter your PIN');
                            agent.setContext({
                                "name": "account_name_context",
                                "lifespan": 1,
                                "parameters": { "account_name": agent.parameters['account-name'] }
                            });
                        }else{
                            console.log("In else***");
                          	agent.setContext({"name":"choose-account-context", "lifespan": -1});
                            if(accountNameTries > 0){
                                agent.add('Sorry!! No such account available.Please enter your phone number.');
                                // phone_number_options.forEach(record => {
                                //     agent.add(new Suggestion(record.Name));
                                // });
                              	agent.setContext({"name": "appointment-followup"});
                                agent.setContext({"name": "phone_number_context", "lifespan": -1});
                                agent.setContext({"name": "phone_number_context", "lifespan": -1});
                              	agent.setContext({"name": "choose-account-followup", "lifespan": -1});                  	
                            }else{
                              	accountNameTries = 1;
                            	agent.add('Sorry!! No such account available.Please renter your phone number');
                                agent.setContext({"name":"phone_number_context", "lifespan": -1});
                            }
                        }
                        break;
                }
                return resolve();
            }).catch(err => {
                switch (agent.originalRequest.source){
                    case "GOOGLE_TELEPHONY":
                        res.json({'fulfillmentText': "Something went wrong while fetching data"});
                        break;
                    default:
                        agent.add("Something went wrong while fetching data");
                }
               return reject();
            });
        });
    }
 
	/***
    	pin-number intent handler
    	@params Agent {WebhookClient}    	
    **/
    function pinNumber(agent) {
        let number_array= {"one":"1","two":"2","three":"3","four":"4","five":"5","six":"6","seven":"7","eight":"8","nine":"9","zero":"0"};
        let input_pin_number_splitted = (agent.parameters.number.toString() ||'').toLowerCase().split(' ');
        let input_pin_number = input_pin_number_splitted.reduce((p,c,i)=>{return p+(number_array[c] || c);},'');
        console.log("INPUT PIN NUMBER", input_pin_number);

        let phone_number = null;
        let account_name = null;

        switch (agent.originalRequest.source){
          case "GOOGLE_TELEPHONY":
                console.log(req.outputContexts, agent.contexts, "===");
            	agent.contexts.forEach(context =>{
                    if(context.name == 'account_name_context'){
                        account_name = context.parameters.account_name;
                    }
                    if(context.name == 'phone_number_context'){
                        phone_number = context.parameters.phone_number;
                    }
				});
            	break;
          default: 
                phone_number = agent.getContext("phone_number_context").parameters.phone_number;
                account_name = agent.getContext("account_name_context").parameters.account_name;
        }
        console.log("****", phone_number, account_name);
        return new Promise((resolve, reject) => {
            conn.collection("Account").select("Id,Name,pin_number__c").where({
                $and: [
                    { "Phone": phone_number },
                    { "Name": account_name }
                ]
            }).limit(1).run().then(response => {
                console.log("PIN NUMBER INTENT", response.records, agent.originalRequest.source);
                if (response.records.length === 0){
                  	switch (agent.originalRequest.source){
                        case "GOOGLE_TELEPHONY":
                        	res.json({'fulfillmentText': "Sorry!! we could not find any records. Ensure that security pin or account name is correct.Please enter your phone number"});
                 
                        break;
                      	default: 
                        	agent.add("Sorry!! we could not find any records. Ensure that security pin or account name is correct");
                    		agent.add("Please enter your phone number");
                     }
                    agent.clearContext("phone_number_context");
                    agent.clearContext("account_name_context");
                  	agent.clearContext("pin-number-followup");
                    resolve();
                } else {
                    let correct_pin_number = response.records[0].pin_number__c;
                    console.log("VALUES(DB,input)", correct_pin_number, input_pin_number);
                    // send response
                    console.log("VALIDATE PIN NUMBER", correct_pin_number == input_pin_number);
                    if (correct_pin_number == input_pin_number){
                      switch (agent.originalRequest.source){
                        case "GOOGLE_TELEPHONY":
                            res.json({'fulfillmentText': "Thank you so much,Have a nice day. Do you want me to transfer the call to your technician."});
                          break;
                        default:
                            agent.add("Thanks. I just looked into our system. The technician is already working on your order; if he’s not at your home, he’s in the neighborhood activating your service and should be by shortly.");
                            agent.add("Do you want me to try to transfer you to your technician now? (Please note: If they’re climbing a phone pole they may not be able to answer you");
                          	agent.add(new Suggestion('Yes'));
                          	agent.add(new Suggestion('No'));
                            agent.clearContext("phone_number_context");
                            agent.clearContext("account_name_context");
                      }
                        resolve();
                    } else {
                        numberOfTries--;
                        agent.setContext({ "name": "pin-number-followup", "lifespan": -1 });
                        if (numberOfTries > 0){
                            agent.add("The pin number entered is incorrect. Please verify your pin");
                            agent.add(`You have ${numberOfTries} attempts remaining`);
                            agent.setContext({
                                "name": "phone_number_context",
                                "lifespan": 1,
                            });
                            agent.setContext({
                                "name": "account_name_context",
                                "lifespan": 1,
                            });
                            agent.setContext({
                                "name": "choose-account-context",
                                "lifespan": 1,
                            });
                        } else {
                            agent.add("Maximum number of tries reached, please start over again");
                            agent.clearContext("phone_number_context");
                            agent.clearContext("account_name_context");
                            numberOfTries = 3;
                        }
                        resolve();
                    }
                }
            }).catch(err => {
                console.error(err);
                switch (agent.originalRequest.source){
                  case "GOOGLE_TELEPHONY":
                      res.json({'fulfillmentText': "Something went wrong while fetching data"});
                      break;
                  default:
                      agent.add("Something went wrong while fetching data");
              	}
                reject();
            });
        });

    }

    login().then(userInfo => {
        intentMap.set("Default Welcome Intent", welcome);
        console.log("User ID: " + userInfo.id);
        console.log("Org ID: " + userInfo.organizationId);
        intentMap.set("Default Fallback Intent", fallback);
        intentMap.set("phone-number", phoneNumber);
        intentMap.set("choose-account", chooseAccount);
        intentMap.set("pin-number", pinNumber);
        agent.handleRequest(intentMap);
    }).catch(err => {
        console.log(err);
      	switch (agent.originalRequest.source){
        	case "GOOGLE_TELEPHONY":
                res.json({'fulfillmentText': "Something went wrong while fetching data"});
            	break;
         	default:
        		agent.add("Something went wrong while fetching data");
        }
     });

});
